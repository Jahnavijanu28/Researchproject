from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from datetime import date
from werkzeug.security import generate_password_hash, check_password_hash
import pymysql

app = Flask(__name__)
CORS(app, supports_credentials=True)

app.config['JWT_SECRET_KEY'] = 'super-secret-key'
jwt = JWTManager(app)

def get_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='Panda123',
        database='Mango',
        cursorclass=pymysql.cursors.DictCursor
    )


@app.after_request
def apply_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response



@app.route('/')
def serve_index():
    return render_template("index.html")


@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    required = ['name', 'email', 'password', 'role']
    if not all(k in data for k in required):
        return jsonify(message="Missing required fields"), 400

    hashed_pw = generate_password_hash(data['password'])
    role = data['role']

    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            if role == 'admin':
                specialty_id = data.get('specialty_id')
                experience = data.get('experience')
                provider_type = data.get('provider_type')

                if not specialty_id or not experience or not provider_type:
                    return jsonify(message="Missing admin-specific fields"), 400

                cursor.execute("""
                    INSERT INTO users (full_name, email, password_hash, role, specialty_id, experience, provider_type)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, (data['name'], data['email'], hashed_pw, role, specialty_id, experience, provider_type))
            else:
                cursor.execute("""
                    INSERT INTO users (full_name, email, password_hash, role)
                    VALUES (%s, %s, %s, %s)
                """, (data['name'], data['email'], hashed_pw, role))

        # ✅ THIS IS CRITICAL
        connection.commit()
        connection.close()

        return jsonify(message="Registration successful"), 201

    except Exception as e:
        return jsonify(message=f"Server error: {str(e)}"), 500




@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify(message="Email and password required"), 400

    connection = get_connection()
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()

        if user and check_password_hash(user['password_hash'], password):
            token = create_access_token(identity=str(user['user_id']))
            return jsonify(access_token=token, user_id=user['user_id'], role=user['role'])

    connection.close()
    return jsonify(message="Invalid email or password"), 401


@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    user_id = get_jwt_identity()
    return jsonify(message=f"Access granted for user {user_id}"), 200


@app.route("/api/doctors_by_id/<int:specialty_id>", methods=["GET"])
def get_doctors_by_specialty_and_provider(specialty_id):
    provider_type = request.args.get("provider_type")
    query = "SELECT user_id, full_name FROM users WHERE role='admin' AND specialty_id=%s"
    params = [specialty_id]
    if provider_type:
        query += " AND provider_type=%s"
        params.append(provider_type)
    with connection.cursor() as cursor:
        cursor.execute(query, params)
        return jsonify(cursor.fetchall())

@app.route("/appointment", methods=["POST"])
@jwt_required()
def create_appointment():
    identity = get_jwt_identity()
    data = request.get_json()
    required = ["appointment_time", "specialty_id", "user_id", "symptoms", "priority", "provider_type"]
    if not all(field in data for field in required):
        return jsonify(message="Missing fields"), 400

    connection = get_connection()
    with connection.cursor() as cursor:
        cursor.execute("""
            INSERT INTO appointments (user_id, appointment_time, specialty_id, doctor_user_id, symptoms, priority, provider_type)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            identity,
            data["appointment_time"],
            data["specialty_id"],
            data["user_id"],
            data["symptoms"],
            data["priority"],
            data["provider_type"]
        ))
        connection.commit()
    connection.close()
    
    return jsonify(message="Appointment booked successfully"), 201


@app.route("/api/patient/appointments", methods=["GET"])
@jwt_required()
def get_patient_appointments():
    user_id = get_jwt_identity()
    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT a.appointment_id, a.appointment_time, a.status, a.priority, a.symptoms,
                u.full_name AS doctor_name, s.name AS specialty, a.provider_type
                FROM appointments a
                JOIN users u ON u.user_id = a.doctor_user_id
                JOIN specialties s ON s.specialty_id = a.specialty_id
                WHERE a.user_id = %s
                ORDER BY a.appointment_time DESC
            """, (user_id,))
            result = cursor.fetchall()
        connection.close()
        return jsonify(result), 200
    except Exception as e:
        return jsonify(message=f"Server error: {str(e)}"), 500


# @app.route("/api/patient/appointments", methods=["GET"])
# @jwt_required()
# def get_patient_appointments():
#     user_id = get_jwt_identity()
#     try:
#         connection = get_connection()
#         with connection.cursor() as cursor:
#             cursor.execute("""
#                 SELECT a.appointment_id, a.appointment_time, a.status, a.priority, -- ✅ added priority
#                        u.full_name AS doctor_name, s.name AS specialty, a.provider_type
#                 FROM appointments a
#                 JOIN users u ON u.user_id = a.doctor_user_id
#                 JOIN specialties s ON s.specialty_id = a.specialty_id
#                 WHERE a.user_id = %s
#                 ORDER BY a.appointment_time DESC
#             """, (user_id,))
#             result = cursor.fetchall()
#         connection.close()
#         return jsonify(result), 200
#     except Exception as e:
#         return jsonify(message=f"Server error: {str(e)}"), 500

@app.route("/api/specialties", methods=["GET"])
def get_specialties():
    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT specialty_id, popup_message FROM specialties")  # added popup_message
            result = cursor.fetchall()
        connection.close()
        return jsonify(result)
    except Exception as e:
        print("🔥 ERROR in /api/specialties:", e)
        return jsonify({"error": str(e)}), 500


@app.route("/api/specialty", methods=["GET"])
def get_specialty():
    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT specialty_id, name FROM specialties")
            result = cursor.fetchall()
        connection.close()
        return jsonify(result)
    except Exception as e:
        print("🔥 ERROR in /api/specialty:", e)
        return jsonify({"error": str(e)}), 500

# Get all distinct provider types (skip specialty dependency)
@app.route("/api/provider_types", methods=["GET"])
def get_provider_types():
    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT DISTINCT provider_type FROM providers")
            rows = cursor.fetchall()
        connection.close()
        return jsonify(rows)
    except Exception as e:
        print("🔥 ERROR in /api/provider_types:", e)
        return jsonify({"error": str(e)}), 500




# Get doctors based on specialty_id and provider_type
@app.route("/api/doctors", methods=["GET"])
def get_doctors_by_specialty_and_type():
    specialty_id = request.args.get("specialty_id")
    provider_type = request.args.get("provider_type")

    if not specialty_id or not provider_type:
        return jsonify({"error": "Missing specialty_id or provider_type"}), 400

    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT user_id, full_name
                FROM users
                WHERE role = 'admin' AND specialty_id = %s AND provider_type = %s
            """, (specialty_id, provider_type))
            doctors = cursor.fetchall()
        connection.close()
        return jsonify(doctors)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/admin/messages", methods=["GET"])
@jwt_required()
def get_admin_messages():
    admin_id = get_jwt_identity()
    priority_filter = request.args.get("priority")

    connection = get_connection()
    with connection.cursor(pymysql.cursors.DictCursor) as cursor:
        query = """
            SELECT 
                a.appointment_id,
                a.user_id AS sender_id,
                u.full_name AS sender_name,
                s.name AS specialty,
                a.symptoms AS body,
                a.priority,
                a.status,
                a.appointment_time
            FROM appointments a
            JOIN users u ON a.user_id = u.user_id
            JOIN specialties s ON a.specialty_id = s.specialty_id
            WHERE a.doctor_user_id = %s
        """
        params = [admin_id]

        if priority_filter and priority_filter != "All":
            query += " AND a.priority = %s"
            params.append(priority_filter)

        query += " ORDER BY a.appointment_time DESC"
        cursor.execute(query, tuple(params))
        messages = cursor.fetchall()

    connection.close()
    return jsonify(messages), 200

@app.route("/api/admin/stats", methods=["GET"])
@jwt_required()
def get_admin_stats():
    user_id = get_jwt_identity()

    connection = get_connection()
    with connection.cursor(pymysql.cursors.DictCursor) as cursor:
        # Get role and provider type
        cursor.execute("SELECT role, provider_type FROM users WHERE user_id = %s", (user_id,))
        user = cursor.fetchone()

        if not user:
            return jsonify(message="User not found"), 404

        if user['role'] == 'admin' and user['provider_type'] is None:
            # Global admin
            cursor.execute("""
                SELECT
                    COUNT(*) AS total,
                    SUM(priority = 'High') AS urgent,
                    SUM(status = 'Completed') AS completed
                FROM appointments
            """)
        else:
            # Doctor/admin with provider_type
            cursor.execute("""
                SELECT
                    COUNT(*) AS total,
                    SUM(priority = 'High') AS urgent,
                    SUM(status = 'Completed') AS completed
                FROM appointments
                WHERE doctor_user_id = %s
            """, (user_id,))

        stats = cursor.fetchone()

    connection.close()
    return jsonify(stats), 200
@app.route("/api/admin/appointments/<int:appointment_id>/complete", methods=["POST"])
@jwt_required()
def mark_appointment_completed(appointment_id):
    admin_id = get_jwt_identity()

    connection = get_connection()
    with connection.cursor() as cursor:
        # Ensure appointment belongs to this doctor/admin
        cursor.execute("""
            SELECT * FROM appointments 
            WHERE appointment_id = %s AND doctor_user_id = %s
        """, (appointment_id, admin_id))
        appointment = cursor.fetchone()

        if not appointment:
            connection.close()
            return jsonify(message="Appointment not found or not authorized"), 404

        # Update status
        cursor.execute("""
            UPDATE appointments SET status = 'Completed'
            WHERE appointment_id = %s
        """, (appointment_id,))
        connection.commit()

    connection.close()
    return jsonify(message="Appointment marked as completed"), 200

@app.route("/api/admin/respond", methods=["POST"])
@jwt_required()
def respond_to_patient():
    data = request.get_json()
    appointment_id = data.get("appointment_id")
    patient_id = data.get("patient_id")
    response_text = data.get("response")

    doctor_id = get_jwt_identity()  # Logged-in admin/doctor's ID

    if not appointment_id or not patient_id or not response_text:
        return jsonify(message="Missing fields"), 400

    try:
        connection = get_connection()
        with connection.cursor() as cursor:
            cursor.execute("""
                INSERT INTO doctor_responses (appointment_id, doctor_id, patient_id, response_text)
                VALUES (%s, %s, %s, %s)
            """, (appointment_id, doctor_id, patient_id, response_text))
            connection.commit()
        return jsonify(message="Response submitted successfully"), 201
    except Exception as e:
        return jsonify(message=f"Server error: {str(e)}"), 500
    finally:
        connection.close()



@app.route("/api/patient/doctor_responses", methods=["GET"])
@jwt_required()
def get_doctor_responses():
    patient_id = get_jwt_identity()

    connection = get_connection()
    with connection.cursor(pymysql.cursors.DictCursor) as cursor:
        cursor.execute("""
            SELECT 
                dr.response_id,
                dr.response_text,
                dr.responded_at,
                u.full_name AS doctor_name,
                a.appointment_time,
                s.name AS specialty
            FROM doctor_responses dr
            JOIN appointments a ON dr.appointment_id = a.appointment_id
            JOIN users u ON dr.doctor_id = u.user_id
            JOIN specialties s ON a.specialty_id = s.specialty_id
            WHERE dr.patient_id = %s
            ORDER BY dr.responded_at DESC
        """, (patient_id,))
        responses = cursor.fetchall()

    connection.close()
    return jsonify(responses), 200

@app.route("/api/admin/today_appointments_detail", methods=["GET"])
@jwt_required()
def get_today_appointments_detail():
    admin_id = get_jwt_identity()
    today = date.today()

    connection = get_connection()
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT 
                a.appointment_id,
                u.full_name AS patient_name,
                s.name AS specialty,
                a.symptoms,
                a.priority,
                a.status,
                a.appointment_time
            FROM appointments a
            JOIN users u ON a.user_id = u.user_id
            JOIN specialties s ON s.specialty_id = a.specialty_id
            WHERE a.doctor_user_id = %s AND DATE(a.appointment_time) = %s
            ORDER BY a.appointment_time DESC
        """, (admin_id, today))
        results = cursor.fetchall()

    connection.close()
    return jsonify(results), 200



@app.route("/patient")
def serve_patient_dashboard():
    return render_template("patient.html")

@app.route("/admin")
def serve_admin_dashboard():
    return render_template("admin.html")
if __name__ == '__main__':
    app.run(debug=True)
    

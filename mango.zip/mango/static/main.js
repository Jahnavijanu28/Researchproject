const BASE_URL = "http://127.0.0.1:5000";

// === Tab Switching ===
function showTab(tabId) {
  document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");

  document.querySelectorAll(".tab").forEach(btn => btn.classList.remove("active"));
  if (tabId === "registerTab") {
    document.querySelector(".tab:nth-child(1)").classList.add("active");
  } else {
    document.querySelector(".tab:nth-child(2)").classList.add("active");
  }
}

// === Admin Role Toggle ===
document.getElementById("regRole").addEventListener("change", (e) => {
  const isAdmin = e.target.value === "admin";
  document.getElementById("adminFields").style.display = isAdmin ? "block" : "none";
  if (isAdmin) {
    loadSpecialties();
    loadProviderTypes();
  }
});

// === Load Specialties ===
function loadSpecialties() {
  fetch(BASE_URL + "/api/specialty")
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById("regSpecialtySelect");
      select.innerHTML = "<option value=''>Select Specialty</option>";
      data.forEach(s => {
        const option = document.createElement("option");
        option.value = s.specialty_id;
        option.textContent = s.name;
        select.appendChild(option);
      });
    });
}

// === Load Provider Types ===
function loadProviderTypes() {
  fetch(BASE_URL + "/api/provider_types")
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById("regProviderTypeSelect");
      select.innerHTML = "<option value=''>Select Provider Type</option>";
      data.forEach(p => {
        const option = document.createElement("option");
        option.value = p.provider_type;
        option.textContent = p.provider_type;
        select.appendChild(option);
      });
    });
}

// === Register Form Submission ===
document.getElementById("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("regName").value;
  const email = document.getElementById("regEmail").value;
  const password = document.getElementById("regPassword").value;
  const role = document.getElementById("regRole").value;

  const payload = { name, email, password, role };

  if (role === "admin") {
    payload.specialty_id = document.getElementById("regSpecialtySelect").value;
    payload.experience = document.getElementById("regExperience").value;
    payload.provider_type = document.getElementById("regProviderTypeSelect").value;
  }

  const res = await fetch(BASE_URL + "/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  alert(data.message);
});

// === Login Form Submission ===
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const res = await fetch(BASE_URL + "/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();

  if (res.ok) {
    localStorage.setItem("token", data.access_token);
    localStorage.setItem("role", data.role);
    localStorage.setItem("user_id", data.user_id);

    if (data.role === "admin") {
      window.location.href = "/admin";
    } else {
      window.location.href = "/patient";
    }
  } else {
    alert(data.message);
  }
});

// === DOM Load Fix: Handle Default Admin Fields on First Load ===
// document.addEventListener("DOMContentLoaded", () => {
//   const regRole = document.getElementById("regRole");
//   const isAdmin = regRole.value === "admin";
//   document.getElementById("adminFields").style.display = isAdmin ? "block" : "none";
//   if (isAdmin) {
//     loadSpecialties();
//     loadProviderTypes();
//   }
  
  
//   // Default tab can be set here if needed
//    showTab("registerTab");
// });

// On first load, simulate default admin tab logic
document.addEventListener("DOMContentLoaded", () => {
  toggleAccountType("patient");  // Now patient is default on load
});

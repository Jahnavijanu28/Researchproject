const BASE_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
  checkAdminAuth();
  loadDashboardStats();
  loadMessages();

  const priorityFilter = document.getElementById("priorityFilter");
  if (priorityFilter) {
    priorityFilter.addEventListener("change", loadMessages);
  }
});

function checkAdminAuth() {
  const role = localStorage.getItem("role");
  if (role !== "admin") {
    alert("Unauthorized access. Redirecting...");
    window.location.href = "/";
  }
}

function logout() {
  localStorage.clear();
  window.location.href = "/";
}

function changeTab(tabId, e) {
  document.querySelectorAll(".tab-content").forEach(tab => tab.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");

  document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));
  if (e) e.currentTarget.classList.add("active");
}

// === Dashboard Stats ===
function loadDashboardStats() {
  const token = localStorage.getItem("token");

  fetch(`${BASE_URL}/api/admin/stats`, {
    headers: {
      Authorization: "Bearer " + token
    }
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("totalAppointments").textContent = data.total || 0;
      document.getElementById("urgentCases").textContent = data.urgent || 0;
      document.getElementById("completedMessages").textContent = data.completed || 0;
    })
    .catch(err => console.error("Stats error:", err));
}

// === Messages List ===
function loadMessages() {
  const token = localStorage.getItem("token");
  const priority = document.getElementById("priorityFilter")?.value;
  let url = `${BASE_URL}/api/admin/messages`;
  if (priority && priority !== "All") {
    url += `?priority=${priority}`;
  }

  fetch(url, {
    headers: {
      Authorization: "Bearer " + token
    }
  })
    .then(res => res.json())
    .then(data => {
      const tableBody = document.getElementById("adminMessagesTable");
      tableBody.innerHTML = "";

      if (!data || data.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="7">No messages found</td></tr>`;
        return;
      }

      data.forEach(msg => {
        const tr = document.createElement("tr");

        const priorityBadge = getPriorityBadge(msg.priority);
        const statusBadge = getStatusBadge(msg.status);

        tr.innerHTML = `
          <td>${msg.sender_name}</td>
          <td>${msg.specialty}</td>
          <td>${msg.body}</td>
          <td>${priorityBadge}</td>
          <td>${statusBadge}</td>
          <td>${new Date(msg.appointment_time).toLocaleString()}</td>
          <td>
            <button class="button-sm button-secondary" onclick="showResponseBox(${msg.appointment_id}, ${msg.sender_id}, this.parentNode.parentNode)">💬 Respond</button>
            ${msg.status === "Pending"
              
              ? `<button class="button-sm button-primary" onclick="markAsCompleted(${msg.appointment_id})">✔️ Complete</button>`

              : ""}
          </td>
        `;
        tableBody.appendChild(tr);
      });
    })
    .catch(err => {
      console.error("Message fetch failed:", err);
    });
}

function getPriorityBadge(priority) {
  if (priority === "High") return `<span class="badge badge-high">High</span>`;
  if (priority === "Moderate") return `<span class="badge badge-moderate">Moderate</span>`;
  return `<span class="badge badge-low">Low</span>`;
}

function getStatusBadge(status) {
  if (status === "Pending") return `<span class="badge badge-warning">Pending</span>`;
  if (status === "Completed") return `<span class="badge badge-success">Completed</span>`;
  return `<span class="badge badge-error">${status}</span>`;
}

function markAsCompleted(appointmentId) {
  const token = localStorage.getItem("token");
  if (!confirm("Mark this appointment as completed?")) return;

  fetch(`${BASE_URL}/api/admin/appointments/${appointmentId}/complete`, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + token
    }
  })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      loadMessages();  // Refresh list
      loadDashboardStats(); // Update stats
    })
    .catch(err => {
      console.error("Failed to update status", err);
      alert("Could not complete the appointment.");
    });
}

function showResponseBox(appointmentId, senderId, rowElement) {
  if (rowElement.nextElementSibling && rowElement.nextElementSibling.classList.contains('response-box')) return;

  const tr = document.createElement("tr");
  tr.className = "response-box";
  const td = document.createElement("td");
  td.colSpan = 7;
  td.innerHTML = `
    <textarea class="response-input" placeholder="Type your response..." id="response_${appointmentId}"></textarea>
    <button class="submit-response-btn" onclick="submitResponse(${appointmentId}, ${senderId})">Send Response</button>
  `;
  tr.appendChild(td);
  rowElement.parentNode.insertBefore(tr, rowElement.nextSibling);
}

async function submitResponse(appointmentId, patientId) {
  const token = localStorage.getItem("token");
  const message = document.getElementById(`response_${appointmentId}`).value;

  if (!message) return alert("Please enter a response.");

  const res = await fetch(`${BASE_URL}/api/admin/respond`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token
    },
    body: JSON.stringify({
      appointment_id: appointmentId,
      patient_id: patientId,
      response: message
    })
  });

  const data = await res.json();
  if (res.ok) {
    alert("Response sent successfully.");
    loadMessages();
  } else {
    alert("Error: " + data.message);
  }
}


async function loadTodayAppointments() {
  const token = localStorage.getItem("token");

  const res = await fetch(`${BASE_URL}/api/admin/today_appointments_detail`, {
    headers: { Authorization: "Bearer " + token }
  });

  const data = await res.json();
  const table = document.getElementById("todayAppointmentsTable");
  table.innerHTML = "";

  if (data.length === 0) {
    table.innerHTML = "<tr><td colspan='6'>No appointments today</td></tr>";
    return;
  }

  data.forEach(app => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${app.patient_name}</td>
      <td>${app.specialty}</td>
      <td>${app.symptoms}</td>
      <td><span class="badge badge-${app.priority.toLowerCase()}">${app.priority}</span></td>
      <td><span class="badge ${app.status === 'Completed' ? 'badge-success' : 'badge-warning'}">${app.status}</span></td>
      <td>${new Date(app.appointment_time).toLocaleString()}</td>
    `;
    table.appendChild(row);
  });
}

// Call this on page load or inside changeTab('dashboard') logic
loadTodayAppointments();

document.addEventListener("DOMContentLoaded", () => {
  const name = localStorage.getItem("full_name") || "Admin";
  document.getElementById("loggedInName").textContent = name;

  // Optionally update avatar initials
  const initials = name.split(" ").map(word => word[0]).join("").toUpperCase();
  document.getElementById("userInitials").textContent = initials;
});

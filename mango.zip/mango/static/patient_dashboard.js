const BASE_URL = "http://127.0.0.1:5000";

function logout() {
  localStorage.clear();
  window.location.href = "/";
}

// function loadAppointments() {
//   const token = localStorage.getItem("token");
//   fetch(`${BASE_URL}/api/patient/appointments`, {
//     headers: { Authorization: "Bearer " + token }
//   })
//     .then(res => res.json())
//     .then(data => {
//       const container = document.getElementById("appointments");
//       container.innerHTML = data.length ? "" : "<p>No appointments found.</p>";
//       data.forEach(app => {
//         const div = document.createElement("div");
//         div.innerHTML = `<strong>${app.specialty}</strong> with <em>${app.doctor_name}</em> on <u>${new Date(app.appointment_time).toLocaleString()}</u> (${app.priority}) - <b>${app.status}</b><hr>`;
//         container.appendChild(div);
//       });
//     });
// }

function loadAppointments() {
  const token = localStorage.getItem("token");
  fetch(`${BASE_URL}/api/patient/appointments`, {
    headers: { Authorization: "Bearer " + token }
  })
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("appointments");
      container.innerHTML = "";

      if (!data.length) {
        container.innerHTML = "<p>No appointments found.</p>";
        return;
      }

      data.forEach(app => {
        const div = document.createElement("div");
        div.className = "appointment-card";

        div.innerHTML = `
          <h4>${app.specialty} (${app.provider_type})</h4>
          <p><strong>Doctor:</strong> ${app.doctor_name}</p>
          <p><strong>Time:</strong> ${new Date(app.appointment_time).toLocaleString()}</p>
          <p><strong>Symptoms:</strong> ${app.symptoms}</p>
          <p><strong>Priority:</strong> <span class="badge ${app.priority}">${app.priority}</span></p>
          <p><strong>Status:</strong> <span class="badge ${app.status}">${app.status}</span></p>
        `;
        container.appendChild(div);
      });
    })
    .catch(err => {
      console.error("Failed to load appointments", err);
    });
}


document.getElementById("specialtySelect").addEventListener("change", loadDoctors);
document.getElementById("providerTypeSelect").addEventListener("change", loadDoctors);

document.getElementById("appointmentForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const token = localStorage.getItem("token");
  const payload = {
    appointment_time: document.getElementById("appointmentDateTime").value,
    specialty_id: document.getElementById("specialtySelect").value,
    user_id: document.getElementById("doctorSelect").value,
    symptoms: document.getElementById("symptomsTextarea").value,
    priority: document.getElementById("prioritySelect").value,
    provider_type: document.getElementById("providerTypeSelect").value
  };

  fetch(`${BASE_URL}/appointment`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token
    },
    body: JSON.stringify(payload)
  })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      document.getElementById("appointmentForm").reset();
      loadAppointments();
    })
    .catch(err => {
      alert("Failed to book appointment.");
      console.error(err);
    });
});

document.addEventListener("DOMContentLoaded", () => {
  
  loadAppointments();
  loadSpecialties();
  loadProviderTypes();
});


// Load specialties
// function loadSpecialties() {
//     fetch(`${BASE_URL}/api/specialties`)
//       .then(res => res.json())
//       .then(data => {
//         console.log("Specialties:", data);  // ✅ For debugging
//         const select = document.getElementById("specialtySelect");
//         select.innerHTML = "<option value=''>Select Specialty</option>";
//         data.forEach(s => {
//           const opt = document.createElement("option");
//           opt.value = s.specialty_id;
//           opt.textContent = s.name;
//           select.appendChild(opt);
//         });
//       })
//       .catch(err => console.error("Error loading specialties:", err));
//   }
  

function loadSpecialties() {
  fetch(`${BASE_URL}/api/specialties`)
    .then(res => res.json())
    .then(data => {
      console.log("Specialties:", data);  // ✅ For debugging
      const select = document.getElementById("specialtySelect");
      select.innerHTML = "<option value=''>Select Specialty</option>";
      data.forEach(s => {
        const opt = document.createElement("option");
        opt.value = s.specialty_id;
        opt.textContent = s.popup_message;  // ✅ Now shows popup_message instead of name
        select.appendChild(opt);
      });
    })
    .catch(err => console.error("Error loading specialties:", err));
}

// Load provider types
function loadProviderTypes() {
    fetch(`${BASE_URL}/api/provider_types`)
      .then(res => res.json())
      .then(data => {
        console.log("Provider types loaded:", data); // 🔍 Add this line
        const select = document.getElementById("providerTypeSelect");
        select.innerHTML = "<option value=''>Select Provider Type</option>";
  
        if (!Array.isArray(data)) return;
  
        data.forEach(p => {
          const type = p.provider_type || p.type; // defensive
          if (type) {
            const opt = document.createElement("option");
            opt.value = type;
            opt.textContent = type;
            select.appendChild(opt);
          }
        });
      })
      .catch(err => console.error("Error loading provider types:", err));
  }
  

// Load doctors when both specialty and provider_type are selected
function loadDoctors() {
  const specialtyId = document.getElementById("specialtySelect").value;
  const providerType = document.getElementById("providerTypeSelect").value;
  if (!specialtyId || !providerType) return;

  const url = `${BASE_URL}/api/doctors?specialty_id=${specialtyId}&provider_type=${encodeURIComponent(providerType)}`;
  fetch(url)
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById("doctorSelect");
      select.innerHTML = "<option value=''>Select Doctor</option>";
      data.forEach(d => {
        const opt = document.createElement("option");
        opt.value = d.user_id;
        opt.textContent = d.full_name;
        select.appendChild(opt);
      });
    });
}

// Attach listeners
document.getElementById("specialtySelect").addEventListener("change", loadDoctors);
document.getElementById("providerTypeSelect").addEventListener("change", loadDoctors);

document.addEventListener("DOMContentLoaded", () => {
  loadSpecialties();
  loadProviderTypes();
});
function changeTab(tabId, e) {
  document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");

  document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));
  if (e) e.currentTarget.classList.add("active");

  if (tabId === "responseSection") {
    loadDoctorResponses();
  }
}


function loadDoctorResponses() {
  const token = localStorage.getItem("token");

  fetch(`${BASE_URL}/api/patient/doctor_responses`, {
    headers: {
      Authorization: "Bearer " + token
    }
  })
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById("responseSection");
    container.innerHTML = "";
    data.forEach(resp => {
      const div = document.createElement("div");
      div.innerHTML = `<b>${resp.doctor_name}</b>: ${resp.response_text} <i>${new Date(resp.responded_at).toLocaleString()}</i>`;
      container.appendChild(div);
    });
  });
}

function loadDoctorResponses() {
  const token = localStorage.getItem("token");

  fetch(`${BASE_URL}/api/patient/doctor_responses`, {
    headers: {
      Authorization: "Bearer " + token
    }
  })
  .then(res => res.json())
  .then(data => {
    const responseContainer = document.getElementById("doctorResponses");
    responseContainer.innerHTML = "";

    if (!data.length) {
      responseContainer.innerHTML = "<p>No responses yet.</p>";
      return;
    }

    data.forEach(resp => {
      const div = document.createElement("div");
      div.classList.add("response-card");
      div.innerHTML = `
        <p><strong>Doctor:</strong> ${resp.doctor_name}</p>
        <p><strong>Specialty:</strong> ${resp.specialty}</p>
        <p><strong>Appointment:</strong> ${new Date(resp.appointment_time).toLocaleString()}</p>
        <p><strong>Response:</strong> ${resp.response_text}</p>
        <p class="timestamp">${new Date(resp.responded_at).toLocaleString()}</p>
      `;
      responseContainer.appendChild(div);
    });
  });
}
